 <?php phpinfo(); ?>
