<?php
class FailureExcepcion extends Exception{

}
?>