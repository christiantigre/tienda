<?php
class UsuarioGenericoViafirma {
	public $firstName;
	public $lastName;
	public $numberUserId;
	public $email;
	public $typeCertificate;
	public $typeLegal;
	public $caName;
	public $properties;
	
	//Solo presentes en los retornos de las firmas
	public $signId;
	public $signTimeStamp;
	
	
}
?>