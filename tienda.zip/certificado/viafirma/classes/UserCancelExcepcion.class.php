<?php
class UserCancelExcepcion extends Exception{

}
?>