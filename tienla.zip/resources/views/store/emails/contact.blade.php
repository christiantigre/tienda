<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="contact-store">
    <meta name="author" content="christian">
    <title>StoreLine</title>
</head><!--/head-->

<body>
    <p>Nombre:<strong>{!!$name!!}</strong></p>
    <p>Correo:<strong>{!!$email!!}</strong></p>
    <p>Mensaje:<strong>{!!$mensaje!!}</strong></p>
</body>
</html>