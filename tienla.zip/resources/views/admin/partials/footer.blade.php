<footer>
          <div class="pull-right">
            Admin <a href="#">Store</a>
          </div>
          <div class="clearfix"></div>
</footer>