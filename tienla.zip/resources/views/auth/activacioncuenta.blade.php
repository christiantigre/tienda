<h1>Bienvenid@</h1>
<p>
Lamentamos haber desactivado cuenta, esto puede haber sido causa de inactividad en nuestro sitio <b>Store-Line</b>
</p>

<a href="{{ url('/') }}/confirm/comfirm_token/{{ $data['comfirm_token'] }}/email/{{ $data['email'] }}"> Activar mi cuenta </a>