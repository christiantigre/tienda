@extends('store.template')

@section('content')
<div class="row">
				<div class="col-sm-3">
                    registrado
                </div>
				
				<div class="col-sm-9 padding-right">
					
				</div>
			</div>
@stop