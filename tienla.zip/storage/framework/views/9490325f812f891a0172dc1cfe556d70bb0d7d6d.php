<?php $__env->startSection('content'); ?>
<h1>Detalle del producto</h1>
<div class="product-details">
    <img src="<?php echo e($product->img); ?>" width="300" >
</div>
<div class="product-details">
    <h3><?php echo e($product->nombre); ?></h3>
</div>
<p>
    <a href="<?php echo e(route('home')); ?>">Regresar</a>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>