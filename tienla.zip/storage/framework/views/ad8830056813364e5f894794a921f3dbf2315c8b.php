<?php $__env->startSection('content'); ?>
	<!-- page content -->
      <div class="right_col" role="main">

        <div class="">
          <div class="page-title">
            <div class="title_left">
              <h3>
                    Detalle 
                    <small>
                        de pedido
                    </small>
                </h3>
            </div>

            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search for...">
                  <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>

          <div class="row">
          	<?php echo Form::model($pedido, array('route' => array('admin.sales.update', $pedido->id))); ?>

            <input type="hidden" name="_method" value="PUT">
            <div class="col-md-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2> <small>Gestión</small></h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">

                  <section class="content invoice">
                    <!-- title row -->
                    <div class="row">
                      <div class="col-xs-12 invoice-header">
                        <h1>
                                        <i class="fa fa-globe"></i> Pedido.
                                        <small class="pull-right">Date: <?php echo e($pedido->date); ?></small>
                                    </h1>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- info row -->
                    <div class="row invoice-info">
                      <div class="col-sm-4 invoice-col">
                        Tienda
                <address>
                  	<?php foreach($dt_empress as $dt_empres): ?>   
                    <strong><?php echo e($dt_empres->nom); ?></strong>
                    <br><?php echo e($dt_empres->dir); ?>

                    <br><?php echo e($dt_empres->prov); ?> - <?php echo e($dt_empres->ciu); ?>

                    <br><?php echo e($dt_empres->count); ?>

                    <br>tlf: <?php echo e($dt_empres->tlfun); ?>/<?php echo e($dt_empres->tlfds); ?>

                    <br>Email: <?php echo e($dt_empres->email); ?>

                    <?php endforeach; ?>
                </address>
                      </div>
                      <!-- /.col -->
                      <div class="col-sm-4 invoice-col">
                        Cliente
                <address>
              		<?php foreach($perfil as $perfils): ?>
	                <strong><?php echo e($perfils->name); ?> <?php echo e($perfils->apellidos); ?></strong>
                	<br><?php echo e($perfils->dir1); ?>

                	<br><?php echo e($perfils->dir2); ?>

                	<br>tlf: <?php echo e($perfils->telefono); ?>/<?php echo e($perfils->celular); ?>

                	<br>Email: <?php echo e($perfils->email); ?>

                	<?php endforeach; ?>
                </address>
                      </div>
                      <!-- /.col -->
                      <div class="col-sm-4 invoice-col">
                        <b>Pedido </b>
				          <br>
				          <br>
				          <b>Estado del pedido :</b><?php echo Form::select('status_id', $status, null,['class'=>'form-control']); ?>

<br>
				           <?php echo e($pedido->status->statu); ?>

				          <br>
				          <b>Forma de pago:</b> <?php echo e($pedido->paymethods->namemethod); ?>

				          <br>
				          <b>Entrega de pedido :</b> <?php echo e($pedido->entrega); ?>

                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <!-- Table row -->
                    <div class="row">
                      <div class="col-xs-12 table">
                        <table class="table table-striped">
                          <thead>
		                      <tr>
		                        <th>Producto</th>
		                        <th>Precio</th>
		                        <th style="width: 59%">Cantidad</th>
		                        <th>Subtotal</th>
		                      </tr>
		                    </thead>
		                    <?php foreach($item as $itemp): ?>
		                    <tbody>
		                      <tr>
		                        <td><?php echo e($itemp->products->nombre); ?></td>
		                        <td><?php echo e(number_format($itemp->products->pre_ven,2)); ?></td>
		                        <td><?php echo e($itemp->cant); ?></td>
		                        <td>$<?php echo e(number_format( $itemp->prec * $itemp->cant,2 )); ?></td>
		                      </tr>
		                    </tbody>
		                    <?php endforeach; ?>
                        </table>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <div class="row">
                      <!-- accepted payments column -->
                      <div class="col-xs-6">
                        
                      </div>
                      <!-- /.col -->
                      <div class="col-xs-6">
                        <p class="lead">Date: <?php echo e($pedido->date); ?></p>
                        <div class="table-responsive">
                          <table class="table">
		                      <tbody>
		                        <tr>
		                          <th style="width:50%">Subtotal:</th>
		                          <td>$<?php echo e($pedido->subtotal); ?></td>
		                        </tr>
		                        <tr>
		                          <th>Iva (14%)</th>
		                          <td>$<?php echo e($pedido->iva); ?></td>
		                        </tr>
		                        <tr>
		                          <th>Total:</th>
		                          <td>$<?php echo e($pedido->total); ?></td>
		                        </tr>
		                      </tbody>
		                    </table>
                        </div>
                      </div>
                      <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <!-- this row will not appear when printing -->
                    <div class="row no-print">
                      <div class="col-xs-12">
                        <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>

                        <?php echo Form::submit('Actualizar', array('class'=>'btn btn-success')); ?>

                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
          <?php echo e(Form::close()); ?> 
        </div>

        

      </div>
      <!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>