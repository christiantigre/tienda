<h1>Bienvenid@</h1>
<p>
Lamentamos haber desactivado cuenta, esto puede haber sido causa de inactividad <b>Store-Line</b>
</p>

<a href="<?php echo e(url('/')); ?>/confirm/comfirm_token/<?php echo e($data['comfirm_token']); ?>/email/<?php echo e($data['email']); ?>"> Confirmar mi cuenta </a>