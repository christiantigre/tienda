<?php $__env->startSection('content'); ?>

<?php if(Session::has('flash_message.message')): ?>
<div class="alert alert-<?php echo e(Session::get('flash_message.level')); ?>">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<?php echo e(Session::get('flash_message.message')); ?>

</div>
<?php endif; ?>


<div class="row">
	<div class="col-sm-3">
		<div class="left-sidebar">
			<h2>Category</h2>
			<!--category-productsr-->
			<?php echo $__env->make('store.partials.category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<!--/category-productsr-->

			<!--brands_products-->
			<?php echo $__env->make('store.partials.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<!--/brands_products-->

			<div class="price-range"><!--price-range-->
				<h2>Price Range</h2>
				<div class="well">
					<input type="text" class="span2" value="" data-slider-min="0" data-slider-max="600" data-slider-step="5" data-slider-value="[250,450]" id="sl2" ><br />
					<b>$ 0</b> <b class="pull-right">$ 600</b>
				</div>
			</div><!--/price-range-->

			<div class="shipping text-center"><!--shipping-->
				<img src="<?php echo e(asset('images/home/shipping.jpg')); ?>" alt="" />
			</div><!--/shipping-->

		</div>
	</div>
	<div class="col-sm-9 padding-right">
		<div class="product-details"><!--product-details-->
			<div id="window" class="magnify">
				<div class="magnify_glass"> </div>
				<div class = "element_to_magnify">
					<img src="<?php echo e($product->img); ?>" draggable="false"/>
				</div>
			</div>
			<div class="col-sm-5">
						<div class="view-product">
							<img src="<?php echo e($product->img); ?>" alt="" />
	    				</div>
						<h3>ZOOM</h3>
			</div>
			<div class="col-sm-7">
				<div class="product-information"><!--/product-information-->

					<img src="<?php echo e(asset('images/product-details/new.jpg')); ?>" class="newarrival" alt="" />
					<h2><?php echo e($product->prgr_tittle); ?></h2>
					<p><?php echo e($product->nombre); ?></p>
					<p><?php echo e($product->category->name); ?></p>
					<!--<img src="images/product-details/rating.png" alt="" />-->
					<span>
						<span>US $<?php echo e(number_format($product->pre_ven,2)); ?></span>
						<label>Quantity:</label>
						<input type="number" value="1" />
						<a href="<?php echo e(route('cart-add', $product->slug)); ?>" class="btn btn-fefault cart">
							<i class="fa fa-shopping-cart"></i>
							Add to cart
						</a>
					</span>
					<p><b>Disponible :</b> <?php echo e($product->cant); ?></p>
					<p><b>Condición :</b> New</p>
					<p><b>Marca :</b> <?php echo e($product->brand->brand); ?></p>
					<a href="">
						<!--<img src="images/product-details/share.png" class="share img-responsive"  alt="" />-->
					</a>
				</div><!--/product-information-->
			</div>
		</div><!--/product-details-->





	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>