<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="contact-store">
    <meta name="author" content="christian">
    <title>StoreLine</title>
</head><!--/head-->

<body>
    <p>Nombre:<strong><?php echo $name; ?></strong></p>
    <p>Correo:<strong><?php echo $email; ?></strong></p>
    <p>Mensaje:<strong><?php echo $mensaje; ?></strong></p>
</body>
</html>