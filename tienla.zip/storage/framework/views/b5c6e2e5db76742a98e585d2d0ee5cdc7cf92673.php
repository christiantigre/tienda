<?php $__env->startSection('content'); ?>
<div class="col-sm-8">
        <div class="signup-form">
                        <h2>Registro de usuario</h2>
            <?php if(Session::has('flash_message')): ?>
                <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <?php echo e(Session::get('flash_message')); ?>

                </div>
            <?php endif; ?>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Nombre</label>

                            <div class="col-md-8">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>



                        <div class="form-group">
                                <label for="email" class="col-md-4 control-label">Fecha de nacimiento</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="datetimepicker1" name="datetimepicker1" value="" required="required" onchange="" onblur="age(this.value)"/>
                                    <input id="edad" type="hidden" class="form-control" name="edad" value="" required="required">
                                    <?php if($errors->has('age')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('age')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>                       
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail</label>

                            <div class="col-md-8">
                                <input id="email" type="email" class="form-control" name="email" value="" >

                                <?php if($errors->has('em
                                ail')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Contraseña</label>

                            <div class="col-md-8">
                                <input id="password" type="password" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label for="password-confirm" class="col-md-4 control-label">Confirma contraseña</label>

                            <div class="col-md-8">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Register
                                </button>
                                <p>
                                <span>
                                     <div class="col-md-1 col-md-offset-2">
                                        <?php echo e(Form::checkbox('terms_of_service', 1, null)); ?>                                           
                                    </div>                            
                                Acepto los términos, condiciónes y la Declaración de privacidad
                                </span>
                                </p>
                                
                                <?php if($errors->has('terms_of_service')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('terms_of_service')); ?> </strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                    </form>
        </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>