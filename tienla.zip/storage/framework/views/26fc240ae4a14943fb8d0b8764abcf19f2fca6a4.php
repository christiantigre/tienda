<?php $__env->startSection('content'); ?>

			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Shopping Cart</li>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<?php if(count($cart)): ?>
				<a class="btn btn-danger" href="<?php echo e(route('cart-trash')); ?>">VACIAR CARRITO</a>

				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						<?php foreach($cart as $item): ?>
						<tr>
							<td class="cart_product">
								<a href=""><img src="<?php echo e($item->img); ?>" alt="" width="60"></a>
							</td>
							<td class="cart_description">
								<h4><a href=""><?php echo e($item->nombre); ?></a></h4>
							</td>
							<td class="cart_price">
								<p><?php echo e(number_format($item->pre_ven,2)); ?></p>
							</td>
							<td>								
									<input 
										type="number"
										min="1"
										max="100"
										value="<?php echo e($item->cant); ?>"
										id="product_<?php echo e($item->id); ?>"
									>
									<a 
										href="#" 
										class="btn btn-warning btn-update-item"
										data-href="<?php echo e(route('cart-update',[ $item->slug, null] )); ?>"
										data-id = "<?php echo e($item->id); ?>"
									>
										<i class="fa fa-refresh"></i>
									</a>
							</td>
							<td class="cart_total">
								<p class="cart_total_price"><?php echo e(number_format( $item->pre_ven * $item->cant,2 )); ?></p>
							</td>
							<td class="cart_delete">
								<a class="cart_quantity_delete" href="<?php echo e(route('cart-delete', $item->slug)); ?>"><i class="fa fa-times"></i></a>
							</td>
						</tr>
						<?php endforeach; ?>
						
					</tbody>
				</table>
				<?php else: ?>
					<h3>No hay Items en su carrito</h3>
				<?php endif; ?>
				<hr>
				<a class="btn btn-primary" href="<?php echo e(route('home')); ?>">SEGUIR COMPRANDO</a>
			</div>
			<script>
            $(document).ready(function(){
            $(".btn-update-item").on('click', function(e){
            e.preventDefault();        
            var id = $(this).data('id');
            var href = $(this).data('href');
            var cant = $('#product_' + id).val();
            window.location.href = href + "/" + cant;        	
            });
            });
        	</script>


			<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>