<h1>Bienvenid@ <?php echo e($data['name']); ?></h1>
<p>
Por motivos de seguridad debes hacer click en el siguiente enlace para que puedas disfrutar de todos nuestros servicios en <b>Store-Line</b>
</p>

<a href="<?php echo e(url('/')); ?>/confirm/comfirm_token/<?php echo e($data['comfirm_token']); ?>/email/<?php echo e($data['email']); ?>"> Confirmar mi cuenta </a>