<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http=//www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8">
	<title>.: <?php echo $__env->yieldContent('tittle','TiendaLine'); ?> :.</title>

	<!--estilos-->
	<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('admin/fonts/css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/prettyPhoto.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/price-range.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('zoomy/css/jfMagnify.css')); ?>" rel="stylesheet" type="text/css" />
	<script src="http://code.jquery.com/jquery-2.2.0.min.js"></script>
	<script type="text/javascript" src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('zoomy/js/jquery.jfMagnify.min.js')); ?>"></script>
	<script type="text/javascript">
	$(document).ready(function() {
		var scaleNum = 2;
		$(".magnify").jfMagnify();
		$('.plus').click(function(){
			scaleNum += .5;
			if (scaleNum >=3) {
				scaleNum = 3;
			};
			$(".magnify").data("jfMagnify").scaleMe(scaleNum);
		});
		$('.minus').click(function(){
			scaleNum -= .5;
			if (scaleNum <=1) {
				scaleNum = 1;
			};
			$(".magnify").data("jfMagnify").scaleMe(scaleNum);
		});
		$('.magnify_glass').animate({
			'top':'60%',
			'left':'60%'
		},{
			duration: 3000, 
			progress: function(){
				$(".magnify").data("jfMagnify").update();
			}, 
			easing: "easeOutElastic"
		});
	});
	</script>
</head>

<body>
	<div class="right_col" role="main">
	<header id="header"><!--header-->
		<?php echo $__env->make('store.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</header>


<section id="advertisement">

        <div class="container">
<div class="col-sm-12 padding-right">
		<div class="product-details"><!--product-details-->
			<div class="col-sm-5">

				<div id="window" class="magnify" data-magnified-zone=".mg_zone">
					<div class="magnify_glass">
						<div class="mg_ring"></div>
						<div class="pm_btn plus"><h2 class="ext">+</h2></div>
						<div class="pm_btn minus"><h2 class="ext">-</h2></div>
						<div class="mg_zone"></div>
					</div>
					<div class = "element_to_magnify">
						<img src="<?php echo e($product->img); ?>"/>
					</div>
				</div>

						
			</div>
			<div class="col-sm-7">
				<div class="product-information"><!--/product-information-->

					<img src="<?php echo e(asset('images/product-details/new.jpg')); ?>" style="width:50px;" class="newarrival" alt="" />
					<h2><?php echo e($product->prgr_tittle); ?></h2>
					<p><?php echo e($product->nombre); ?></p>
					<p><?php echo e($product->category->name); ?></p>
					<!--<img src="images/product-details/rating.png" alt="" />-->
					<span>
						<span>US $<?php echo e(number_format($product->pre_ven,2)); ?></span>
						<label>Quantity:</label>
						<input type="number" value="1" />
						<a href="<?php echo e(route('cart-add', $product->slug)); ?>" class="btn btn-fefault cart">
							<i class="fa fa-shopping-cart"></i>
							Add to cart
						</a>
					</span>
					<p><b>Disponible :</b> <?php echo e($product->cant); ?></p>
					<p><b>Condición :</b> New</p>
					<p><b>Marca :</b> <?php echo e($product->brand->brand); ?></p>
					<a href="">
						<!--<img src="images/product-details/share.png" class="share img-responsive"  alt="" />-->
					</a>
				</div><!--/product-information-->
			</div>
		</div><!--/product-details-->





</div>

</div>
    </section>
		

		<!-- footer content -->
		<footer>
			<?php echo $__env->make('store.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
		</footer>
		<!-- /footer content -->

	</div>
	<!-- /page content -->

</body>
</html>
