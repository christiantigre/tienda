<?php $__env->startSection('content'); ?>

<section id="cart_items">
        <div class="container">
            <div class="table-responsive cart_info">
                <table class="table table-condensed">
                    <thead>
                        <tr class="cart_menu">
                            <td class="price">Fecha</td>
                            <td class="price">Estado</td>
                            <td class="price">Total</td>
                            <td class="price">Forma de pago</td>
                            <td class="price">Lugar de entrega</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($pedidos as $pedido): ?>
                        <tr>
                            <td class="cart_price">
                                <p><?php echo e($pedido->date); ?></p>
                            </td>
                            <td class="cart_price">
                                <p><?php echo e($pedido->status->statu); ?></p>
                            </td>
                            <td class="cart_price">
                                <p>$<?php echo e(number_format($pedido->total,2)); ?></p>
                            </td>
                            <td class="cart_price">
                                <p><?php echo e($pedido->paymethods->namemethod); ?></p>
                            </td>
                            <td class="cart_price">
                                <p class="cart_total_price"><?php echo e($pedido->entrega); ?></p>
                            </td>
                            <td class="cart_delete">
                                <a class="cart_quantity_delete" href="<?php echo e(route('mysalesshow',$pedido->id)); ?>" tittle="MOSTRAR"><i class="fa fa-eye"></i></a>
                            </td>
                        </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section> <!--/#cart_items-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>