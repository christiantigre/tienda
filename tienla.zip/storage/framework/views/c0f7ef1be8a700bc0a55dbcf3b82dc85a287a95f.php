<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">    
        <div class="">  
<div class="page-title">
            <div class="title_left">
              <h3>
                    Nueva Marca
                    <small>
                        
                    </small>
                </h3>
            </div>

            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search for...">
                  <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                </div>
              </div>
            </div>

            </div>
          <div class="clearfix">

          </div>
<div class="row">
            <?php if(count($errors) > 0): ?>
            	<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
            <?php endif; ?>
	<div class="col-md-10 col-sm-10 col-xs-10">
            <div class="x_content">
                  <?php echo Form::open(['route'=>'admin.brand.store']); ?>

                  <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Marca :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                      	<?php echo Form::text(
                      		'brand',
                      		null,
                      		array(
                      			'class'=>'form-control',
                      			'placeholder'=>'Ingrese nombre de la marca',
                            'required'=>'required',
                      			'autofocus'=>'autofocus'
                      		)
                      	); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Estado :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                        <?php echo Form::select('statu_id', $status, null,['class'=>'form-control']); ?>

                      </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                      	<?php echo Form::submit('Guardar', array('class'=>'btn btn-success')); ?>

                      	<a href="<?php echo e(route('admin.brand.index')); ?>" class="btn btn-primary">Cancelar</a>
                      </div>
                    </div>
                    <?php echo e(Form::close()); ?>

    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>