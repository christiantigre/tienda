<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>.: <?php echo $__env->yieldContent('tittle','TiendaLine'); ?> :.</title>
</head>


<body>
	<?php echo $__env->make('store.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('store.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>


</html>