<h1>Bienvenid@ <?php echo e($data['name']); ?></h1>

<a href="<?php echo e(url()); ?>/confirm/email/<?php echo e($data['email']); ?>/comfirm_token/<?php echo e($data['comfirm_token']); ?>"> Comfirmar mi cuenta </a>