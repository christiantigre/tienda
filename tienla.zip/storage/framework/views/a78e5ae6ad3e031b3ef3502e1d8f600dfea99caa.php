<?php $__env->startSection('content'); ?>

<!--<form method="POST" role="form">-->
<h3> DETALLE DEL PEDIDO </h3>
<div class="col-md-6 col-sm-6 col-xs-12 animated fadeInDown">
  <?php echo Form::open(array
  (
    'route'=>'confir_comp',
    'class'=>'form-horizontal form-label-left',
    'method'=>'POST',
    'role'=>'form',
    'id'=>'formulario'
  )); ?>

  <div class="web-application">
    <div class="col-sm-12">
      <h4 class="brief"><i><small>Datos del Usuario</small></i></h4>
      <div class="left col-xs-7">
        <h2><small><?php echo e($perfil->name); ?> <?php echo e($perfil->apellidos); ?></small></h2>
        <p><strong>Email : </strong><?php echo e($perfil->email); ?>. </p>
        <ul class="list-unstyled">
          <li><i class="fa fa-phone"></i> Teléfono : <?php echo e($perfil->telefono); ?></li>
          <li><i class="fa fa-mobile"></i> Celular : <?php echo e($perfil->celular); ?></li>
        </ul>
        <ul class="list-unstyled">
          <li><i class="fa fa-location-arrow"></i> Dirección 1 : <?php echo e($perfil->dir1); ?></li>
          <li><i class="fa fa-location-arrow"></i> Dirección 2 : <?php echo e($perfil->dir2); ?></li>
        </ul>
        <input type="hidden" name="lt" id="lt" value="<?php echo e($perfil->lt); ?>"/>
        <input type="hidden" name="lg" id="lg" value="<?php echo e($perfil->lg); ?>"/> 
        <input type="hidden" name="latlng" id="latlng" value="<?php echo e($perfil->lt); ?>, <?php echo e($perfil->lg); ?>"/> 

        <input type="hidden" name="ln" id="ln" value="<?php echo e($dt_empress->ln); ?>"/>
        <input type="hidden" name="lgemp" id="lgemp" value="<?php echo e($dt_empress->lg); ?>"/>

      </div>
      <div class="right col-xs-5 text-center">
      </div>
    </div>
  </div>
  <!--<?php echo Form::open(['class'=>'form-horizontal form-label-left']); ?>-->

  <div class="well profile_view">
    <div class="web-application">
      <h4 class="brief"><i><small>Selecione tipo de Entrega</small></i></h4>
      <div class="row fontawesome-icon-list">
        <ul class="list-unstyled">
          <li><i class="fa fa-map-marker"></i> Ubicación actual : <input type="radio" name="rad" id="rad" value="UBICACION" onclick="cargarmap()"/></li>
          <li><i class="fa fa-automobile"></i> Envío a domicilio : <input type="radio" name="rad" id="submit" value="DOMICILIO" onclick="domicilio()"/></li>
          <li><i class="fa fa-child"></i> Voy por mi pedido : <input type="radio" name="rad" id="rad" value="RETIRO" onclick="localStore()" checked="" required/></li>
        <?php echo Form::hidden('lat', '0', array('id' => 'lat')); ?>

        <?php echo Form::hidden('long', '0', array('id' => 'long')); ?>

        <?php echo Form::hidden('entrega', 'Retiro personal', array('id' => 'entrega')); ?>


        </ul>
      </div>
      <div class="right col-xs-5 text-center">
        <input type="hidden" id="res" size="20">
        
      </div>
    </div>
    <div class="web-application">
      <h4 class="brief"><i><small>Selecione forma de pago</small></i></h4>
      <div class="row fontawesome-icon-list">
        <ul class="list-unstyled">
          <li><i class="fa fa-usd"></i> Forma : 
             <?php echo Form::select('id', $pays, null,['class'=>'form-control']); ?>

          </li>
        </ul>
      </div>
      <div class="right col-xs-5 text-center">
        <input type="hidden" id="res" size="20">        
      </div>
    </div>
  </div>


  <div class="well profile_view">
    <div class="web-application">
      <h4 class="brief"><i><small>Lugar de entrega</small></i></h4>
      <!-- Se determina y escribe la localizacion -->
      <div id='ubicacion' style='display:none;'></div> 
      <!---->
      <div class="col-md-3 col-sm-4 col-xs-12" id="demo"></div>
      <div class="row fontawesome-icon-list" id="mapholder"></div>
      <div class="row fontawesome-icon-list" id="floating-panel">
        <b>Mode of Travel: </b>
        <select id="mode">
          <option value="DRIVING">Driving</option>
          <option value="WALKING">Walking</option>
          <option value="BICYCLING">Bicycling</option>
          <option value="TRANSIT">Transit</option>
        </select>
      </div>
    </div>
  </div>
 

  <!--<?php echo e(Form::close()); ?>-->
</div>
<div class="col-md-6 col-sm-6 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
      <h4><small>Datos del Pedido</small></h4>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">

      <table class="table">
        <thead>
          <tr>
            <th>ITEM</th>
            <th>PRECIO</th>
            <th>CANTIDAD</th>
            <th>TOTAL</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($cart as $item): ?>
          <tr>
           <td>
            <img src="<?php echo e($item->img); ?>" alt="" width="60">
            <?php echo e($item->nombre); ?>

          </td>
        </td>
        <td>
          <p><?php echo e(number_format($item->pre_ven,2)); ?></p>
        </td>
        <td>
          <p><?php echo e($item->cantt); ?></p>	
        </td>
        <td>
          <p class="cart_total_price"><?php echo e(number_format( $item->pre_ven * $item->cantt,2 )); ?></p>
        </td>
      </tr>

      <?php endforeach; ?>
    </tbody>
    <tr>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">
        <table class="table table-condensed total-result">
          <tr>
            <td>Sub Total</td>
            <td>$<?php echo e(number_format($sub,2)); ?></td>
          </tr>
          <tr>
            <td>Iva</td>
            <td>$<?php echo e(number_format($iva,2)); ?></td>
          </tr>
          <tr>
            <td>Total</td>
            <td><span>$<?php echo e(number_format($total,2)); ?></span></td>
          </tr>
          <tr>
          </table>
        </td>
      </tr>
      <tr>
       <td colspan="2">&nbsp;</td>
       <td colspan="2">
        <table>
         <tr>
           <hr>
            <?php echo e(Form::input('submit',null,'CONFIRMAR COMPRA', array('class'=>'btn btn-primary fa fa-shopping-cart','id' => 'btn' ))); ?>

           <br>
         </tr>
       </table>
     </td>
   </tr>

 </table>

</div>
</div>
</div>
<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>