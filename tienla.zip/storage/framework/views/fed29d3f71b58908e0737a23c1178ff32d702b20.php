<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">    
        <div class="">  
<div class="page-title">
            <div class="title_left">
              <h3>
                    Registra Personal
                    <small>
                        
                    </small>
                </h3>
            </div>

            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search for...">
                  <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                </div>
              </div>
            </div>

            </div>
          <div class="clearfix">

          </div>
<div class="row">
<?php if(count($errors) > 0): ?>
            	<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
            <?php endif; ?>
	<div class="col-md-10 col-sm-10 col-xs-10">
              
                <div class="x_content">
                  <?php echo Form::open(['route'=>'admin.emp.store'],['class'=>'form-horizontal form-label-left']); ?>


                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Departamento :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                      	<?php echo Form::select('department_id',	$departments, null,['class'=>'form-control','autofocus'=>'autofocus']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Cargo :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                        <?php echo Form::select('cargo_id',  $positions, null,['class'=>'form-control']); ?>

                        </div>
                    </div>

                    


                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Nombres :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                        <?php echo Form::text(
                          'nombres',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Ingrese nombres...',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>

                        <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                      </div>
                    </div>


                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Apellidos :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                        <?php echo Form::text(
                          'apellidos',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Ingrese apellidos',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>

                        <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                      </div>
                    </div>

                    

                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="date">Fecha de nacimiento :</label>
                         <div class="col-md-9 col-sm-9 col-xs-12">
                            
                              <!--<input type="text" class="form-control has-feedback-left" id="single_cal2" placeholder="F. nacimiento" aria-describedby="inputSuccess2Status2">
                              -->
                              <?php echo Form::text(
                          'fechanacimiento',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'F. nacimiento',
                            'id'=>'single_cal2',
                            'autofocus'=>'autofocus'
                          )
                        ); ?> 
                              <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                              <span id="inputSuccess2Status2" class="sr-only">(success)</span>
                            
                        </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Genero :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                         <?php echo Form::select('genero', ['2' => 'Masculino', '1' => 'Femenino'], 'M',['class'=>'form-control']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Num# cedula :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                          <?php echo Form::text(
                          'cedula',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Ingrese CI',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>       
                        <span class="fa fa-cc form-control-feedback left" aria-hidden="true"></span>              
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Telefono :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                          <?php echo Form::text(
                          'telefono',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Ingrese num telefono',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>                    
                        <span class="fa fa-phone form-control-feedback left" aria-hidden="true"></span>                  
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Celular :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                          <?php echo Form::text(
                          'celular',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Ingrese num celular',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>  
                        <span class="fa fa-mobile form-control-feedback left" aria-hidden="true"></span>                  
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Correo :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                          <?php echo Form::text(
                          'email',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Ingrese email del emp...',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>    
                        <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>                
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Foto :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                          <?php echo Form::text(
                          'img',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Url de imagen',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>     
                         <span class="fa fa-photo form-control-feedback left" aria-hidden="true"></span>               
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Direccion :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                          <?php echo Form::text(
                          'dir',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Ingrese direccion',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>   
                        <span class="fa fa-map-marker form-control-feedback left" aria-hidden="true"></span>                 
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Sueldo :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                          <?php echo Form::text(
                          'sld',
                          null,
                          array(
                            'class'=>'form-control has-feedback-left',
                            'placeholder'=>'Sueldo mensual emp...',
                            'autofocus'=>'autofocus'
                          )
                        ); ?>   
                        <span class="fa fa-money form-control-feedback left" aria-hidden="true"></span>                 
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Estado civil :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                         <?php echo Form::select('estcivil', ['Soltero' => 'Soltero', 'Casado' => 'Casado','Divorciado' => 'Divorciado','Union libre' => 'Union libre'], 'Casado',['class'=>'form-control']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Pais :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                         <?php echo Form::select('country_id', $countries, null,['class'=>'form-control']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Provincia :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                         <?php echo Form::select('province_id', $provinces, null,['class'=>'form-control']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Estado :</label>
                      <div class="col-md-9 col-sm-9 col-xs-12">
                         <?php echo Form::select('isactive_id', $isactives, null,['class'=>'form-control']); ?>

                      </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                      	<?php echo Form::submit('Guardar', array('class'=>'btn btn-success')); ?>

                      	<a href="<?php echo e(route('admin.emp.index')); ?>" class="btn btn-primary">Cancelar</a>
                      </div>
                    </div>
                    <?php echo e(Form::close()); ?>

        </div>
</div>
</div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>