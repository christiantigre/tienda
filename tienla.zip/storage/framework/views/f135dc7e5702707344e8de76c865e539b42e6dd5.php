<?php $__env->startSection('content'); ?>

<div class="col-sm-4">
    <div class="product-image-wrapper">
        <div class="single-products">
                <div class="productinfo text-center">
                <h1>lista de productos </h1>
                <?php foreach($products as $product ): ?>
                <h3>		<?php echo e($product->nombre); ?>	</H3>	
                <img src="<?php echo e($product->img); ?>" />
                <h2><?php echo e(number_format($product->pre_ven,2)); ?></h2> 
                <p><?php echo e($product->prgr_tittle); ?></p>
                <a href="#" class="btn btn-default add-to-cart">
                    <i class="fa fa-shopping-cart"></i>
                    Add to cart
                </a>
                <a href="<?php echo e(route('product-detail', $product->slug)); ?>" class="btn btn-default add-to-cart">
                    <i class="fa fa-shopping-cart"></i>
                    Leer mas
                </a>

                </div>
                <div class="product-overlay">
                    <div class="overlay-content">
                    <img src="<?php echo e($product->img); ?>" />
                    <h2><?php echo e(number_format($product->pre_ven,2)); ?></h2> 
                    <p><?php echo e($product->prgr_tittle); ?></p>
                    <a href="#" class="btn btn-default add-to-cart">
                        <i class="fa fa-shopping-cart"></i>
                        Add to cart
                    </a>
                    <a href="<?php echo e(route('product-detail', $product->slug)); ?>" class="btn btn-default add-to-cart">
                        <i class="fa fa-shopping-cart"></i>
                        Leer mas
                    </a>
                    </div>
                </div>
            </div>
            <div class="choose">
            <ul class="nav nav-pills nav-justified">
                <li><a href=""><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
                <li><a href=""><i class="fa fa-plus-square"></i>Add to compare</a></li>
            </ul>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>