<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
    </div>
    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_title">
            <h2><small>Detalle de compra </small></h2>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <section class="content invoice">
              <!-- title row -->
              <div class="row">
                <div class="col-xs-12 invoice-header">
                  <h1>
                    <small class="pull-right">Date: <?php echo e($order->date); ?></small>
                  </h1>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  Tienda
                  <address>
                    <strong><?php echo e($dt_empress->nom); ?></strong>
                    <br><?php echo e($dt_empress->dir); ?>

                    <br><?php echo e($dt_empress->prov); ?> - <?php echo e($dt_empress->ciu); ?>

                    <br><?php echo e($dt_empress->count); ?>

                    <br>tlf: <?php echo e($dt_empress->tlfun); ?>/<?php echo e($dt_empress->tlfds); ?>

                    <br>Email: <?php echo e($dt_empress->email); ?>

                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  Cliente
                  <address>
                    <strong><?php echo e($perfil->name); ?> <?php echo e($perfil->apellidos); ?></strong>
                    <br><?php echo e($perfil->dir1); ?>

                    <br><?php echo e($perfil->dir2); ?>

                    <br>tlf: <?php echo e($perfil->telefono); ?>/<?php echo e($perfil->celular); ?>

                    <br>Email: <?php echo e($perfil->email); ?>

                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b>Pedido </b>
                  <br>
                  <br>
                  <b>Estado del pedido :</b> <?php echo e($order->status->statu); ?>

                  <br>
                  <b>Forma de pago:</b> <?php echo e($order->paymethods->namemethod); ?>

                  <br>
                  <b>Entrega de pedido :</b> <?php echo e($order->entrega); ?>

                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-xs-12 table">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th style="width: 59%">Cantidad</th>
                        <th>Subtotal</th>
                      </tr>
                    </thead>
                    <?php foreach($cartord as $item): ?>
                    <tbody>
                      <tr>
                        <td><?php echo e($item->nombre); ?></td>
                        <td><?php echo e(number_format($item->pre_ven,2)); ?></td>
                        <td><?php echo e($item->cantt); ?></td>
                        <td>$<?php echo e(number_format( $item->pre_ven * $item->cantt,2 )); ?></td>
                      </tr>
                    </tbody>
                    <?php endforeach; ?>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                <div class="col-xs-6">
                  <p class="lead"></p>
                  <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                  </p>
                </div>
                <!-- /.col -->
                <div class="col-xs-6">
                  <p class="lead"></p>
                  <div class="table-responsive">
                    <table class="table">
                      <tbody>
                        <tr>
                          <th style="width:50%">Subtotal:</th>
                          <td>$<?php echo e($cartordaux->subtotal); ?></td>
                        </tr>
                        <tr>
                          <th>Iva (14%)</th>
                          <td>$<?php echo e($cartordaux->iva); ?></td>
                        </tr>
                        <tr>
                          <th>Total:</th>
                          <td>$<?php echo e($cartordaux->total); ?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-xs-12">
                  <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
                 </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<!-- /page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>