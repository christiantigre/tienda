<?php $__env->startSection('content'); ?>
<section id="cart_items">
    
        <div class="container">
            <div class="table-responsive cart_info">
                <!-- title row -->
              <div class="row">
                <div class="col-xs-12 invoice-header">
                  <h1>
                    <small class="pull-right">Date: <?php echo e($pedidoshow->date); ?></small>
                  </h1>
                </div>
                <!-- /.col -->
              </div>

                <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  Tienda
                  <address>
                    <?php foreach($dt_empress as $dt_empres): ?>
                    <strong><?php echo e($dt_empres->nom); ?></strong>
                    <br><?php echo e($dt_empres->dir); ?>

                    <br><?php echo e($dt_empres->prov); ?> - <?php echo e($dt_empres->ciu); ?>

                    <br><?php echo e($dt_empres->count); ?>

                    <br>tlf: <?php echo e($dt_empres->tlfun); ?>/<?php echo e($dt_empres->tlfds); ?>

                    <br>Email: <?php echo e($dt_empres->email); ?>

                    <?php endforeach; ?>
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  Cliente
                  <address>
                    <?php foreach($perfil as $pr): ?>
                    <strong><?php echo e($pr->name); ?> <?php echo e($pr->apellidos); ?></strong>
                    <br><?php echo e($pr->dir1); ?>

                    <br><?php echo e($pr->dir2); ?>

                    <br>tlf: <?php echo e($pr->telefono); ?>/<?php echo e($pr->celular); ?>

                    <br>Email: <?php echo e($pr->email); ?>

                    <?php endforeach; ?>
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b>Pedido </b>
                  <br>
                  <br>
                  <b>Estado del pedido :</b> <?php echo e($pedidoshow->status->statu); ?>

                  <br>
                  <b>Forma de pago:</b> <?php echo e($pedidoshow->paymethods->namemethod); ?>

                  <br>
                  <b>Entrega de pedido :</b> <?php echo e($pedidoshow->entrega); ?>

                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

                

                <table class="table table-condensed">
                    <thead>
                        <tr class="cart_menu">
                            <td class="price">Producto</td>
                            <td class="price">Precio</td>
                            <td class="price">Cantidad</td>
                            <td class="price">Total</td>
                            <td></td>
                        </tr>
                    </thead>                   
                    <tbody>
                        <?php foreach($item as $it): ?>
                      <tr>
                        <td class="cart_price"><p><?php echo e($it->products->nombre); ?></p></td>
                        <td class="cart_price"><p><?php echo e(number_format($it->products->pre_ven,2)); ?></p></td>
                        <td class="cart_price"><p><?php echo e($it->cant); ?></p></td>
                        <td class="cart_price"><p>$<?php echo e(number_format( $it->prec * $it->cant,2 )); ?></p></td>
                      </tr>                      
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="4">&nbsp;</td>
                            <td colspan="2">
                                <table class="table table-condensed total-result">
                                    <tr>
                                        <td>Sub Total</td>
                                        <td>$<?php echo e($pedidoshow->subtotal); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Iva (14%)</td>
                                        <td>$<?php echo e($pedidoshow->iva); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Total</td>
                                        <td><span>$<?php echo e($pedidoshow->total); ?></span></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>

                            




            </div>
        </div>
        
    </section> <!--/#cart_items-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>