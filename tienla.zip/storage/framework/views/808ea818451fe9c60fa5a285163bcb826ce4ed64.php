<?php $__env->startSection('content'); ?>
	
	<div class="col-sm-7">
		<h1>Información de perfíl</h1>
		 <div class="x_content">
		 		 <a href="<?php echo e(route('store.perfil.edit',$perfil->id)); ?>" class="btn btn-app">
                    <i class="fa fa-edit"></i>Cambiar
                 </a>        
        </div>
		<div class="product-information">
				<p><b>Nombres :</b> <?php echo e($perfil->name); ?></p>
				<p><b>Apellidos :</b> <?php echo e($perfil->apellidos); ?></p>
				<p><b>Cédula/Pasaporte :</b> <?php echo e($perfil->cedula); ?></p>
				<p><b>Ruc :</b> <?php echo e($perfil->ruc); ?></p>
				<p><b>Fecha de nacimiento :</b> <?php echo e($perfil->fechanacimiento); ?></p>
				<p><b>Genero :</b> <?php echo e($perfil->genero); ?></p>
				<p><b>Teléfono :</b> <?php echo e($perfil->telefono); ?></p>
				<p><b>celular :</b> <?php echo e($perfil->celular); ?></p>
				<p><b>Email :</b> <?php echo e($perfil->email); ?></p>
				<p><b>Provincia :</b> <?php echo e($perfil->provincia_idprovincia); ?></p>
				<p><b>Dirección 1:</b> <?php echo e($perfil->dir1); ?></p>
				<p><b>Direccion 2 :</b> <?php echo e($perfil->dir2); ?></p>
		</div>
	</div>


	<div class="col-sm-7">
		<h1>Configuración de cuenta</h1>
		 <div class="x_content">
		 		 <a href="<?php echo e(url('password/cambiar')); ?>" class="btn btn-app">
                    <i class="fa fa-edit"></i>Cambiar
                 </a>
         </div>
		<div class="product-information">
				<p><b>Usuario :</b> <?php echo e($users->name); ?></p>
				<p><b>Email :</b> <?php echo e($users->email); ?></p>
				<p><b>Clave :</b> *****</p>				
		</div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>